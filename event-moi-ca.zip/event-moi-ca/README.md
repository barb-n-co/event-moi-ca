# event-moi-ca
# App Barb'n Co

## Git :
##### Nom des branches :
BNC-"N°"_QuickSumUp
##### nom des commits :

<type>[optional scope]: <description>

    fix:
    feat: 
    chore:
    docs:
    style:
    refactor:
    perf:
    test:
    
##### Exemple avec scope :
feat(Strings): imports des strings de toutes l'app dans le fichier String.xml
##### Exemple sans scope 
fix: correction du bug qui fait crash l'app lors de la déconexion


## Trello
liens : https://trello.com/b/7MehfOLw/ptut

**Backlog** : Liste de tous les tickets à faire</br>
**A faire**: Liste des tickets prévu pour le sprint</br>
**En cours** : Lorsqu'un ticket est commencé par un dev</br>
**Recette** : Ticket fini, recettage et relecture de la MR par un autre dev, si un bug est trouvé, le déplacer dans "a faire"</br>
**Terminer** : Ticket fini est validé par PO</br>

#### Couleur :
*Bleu* : Ticket concernant l'acteur : Organisateur</br>
*Violet* : Ticket concernant l'acteur : Participant</br>
*Rouge* : Prio 1 du ticket</br>
*Noir* : Ticket concernant la strucutre de l'application</br>

